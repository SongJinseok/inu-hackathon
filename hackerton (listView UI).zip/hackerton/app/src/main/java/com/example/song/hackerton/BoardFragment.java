package com.example.song.hackerton;

import android.content.ClipData;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class BoardFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment



        View v = inflater.inflate(R.layout.fragment_board, container, false);


        //리스트뷰 생성
        ListView listView = (ListView) v.findViewById(R.id.listView);
        boardAdapter adapter = new boardAdapter();
        listView.setAdapter(adapter);
        //


        return v;




    }



}
